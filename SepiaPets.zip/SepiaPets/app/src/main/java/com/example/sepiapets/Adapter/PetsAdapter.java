package com.example.sepiapets.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sepiapets.R;
import com.example.sepiapets.Utils.Utils;
import com.example.sepiapets.Views.PetDetailsActivity;
import com.example.sepiapets.dataClass.Pet;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import de.hdodenhof.circleimageview.CircleImageView;

public class PetsAdapter extends RecyclerView.Adapter<PetsAdapter.MyViewHolder>{

    Context context;
    ArrayList<Pet> petList;
    public PetsAdapter(Context context, ArrayList<Pet> petList) {
        this.petList = petList;
        this.context = context;
    }

    @NonNull
    @Override
    public PetsAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.pets_item, parent, false);
        return new MyViewHolder(itemView);

    }

    @Override
    public void onBindViewHolder(@NonNull PetsAdapter.MyViewHolder myViewHolder, int i) {
        if (petList.get(i).getImageUrl() != null) {
            Utils.loadImage((String) petList.get(i).getImageUrl(), myViewHolder.pet_img, R.drawable.user_profile);
        }else {
            myViewHolder.pet_img.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.user_profile));
        }

        if (petList.get(i).getTitle() != null) {
            myViewHolder.pet_name.setText("" + "" + petList.get(i).getTitle());
        }
        myViewHolder.rel_pet.setOnClickListener(v -> {
            String content_url = petList.get(i).getContentUrl();
            Intent intent = new Intent(context, PetDetailsActivity.class);
            intent.putExtra("pet_details", "" + content_url );
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return petList.size();
    }
    public class MyViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.pet_img)
        ImageView pet_img;

        @BindView(R.id.pet_working_hour)
        TextView pet_working_hour;

        @BindView(R.id.pet_name)
        TextView pet_name;
        @BindView(R.id.rel_pet)
        RelativeLayout rel_pet;

        MyViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
        }
    }
}
