package com.example.sepiapets.Views

import android.os.Bundle
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.example.sepiapets.R
import com.example.sepiapets.databinding.ActivityPetWebViewBinding


class PetWebViewActivity : AppCompatActivity() {
    lateinit var contentUrl:String
    lateinit var binding: ActivityPetWebViewBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_pet_web_view)
        val extras = intent.extras
        if (extras!=null){
            contentUrl = extras.getString("contentUrl").toString()
        }
        /*binding.webView.settings.loadsImagesAutomatically=true
        binding.webView.settings.javaScriptEnabled= true
        binding.webView.scrollBarStyle= View.SCROLLBARS_INSIDE_OVERLAY
        binding.webView.loadUrl(contentUrl)*/
        binding.webView.getSettings().setJavaScriptEnabled(true)
        binding.webView.setWebViewClient(WebViewClient())
        binding.webView.loadUrl(contentUrl)

    }
}