package com.example.sepiapets.login

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.example.sepiapets.Views.MainActivity
import com.example.sepiapets.R
import com.example.sepiapets.Utils.Utils
import com.example.sepiapets.Utils.Utils.simpleMsg
import com.example.sepiapets.dataClass.SettingsData
import com.example.sepiapets.databinding.ActivityLoginActivityBinding
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.text.SimpleDateFormat
import java.time.temporal.ValueRange
import java.util.*


class LoginActivity : AppCompatActivity() {
    private lateinit var loginBinding: ActivityLoginActivityBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loginBinding = DataBindingUtil.setContentView(this, R.layout.activity_login_activity)
        loginBinding.checkWorkingHour.setOnClickListener {
            getDataFromJson()
        }
    }

    private fun getDataFromJson() {
        val jsonFileString = Utils.getJsonFromAssets(
            applicationContext, "config.json"
        )
        val gson = Gson()
        val listUserType = object : TypeToken<SettingsData?>() {}.type
        val workingHour = gson.fromJson<SettingsData>(jsonFileString, listUserType)
        Log.e("stringgggggggg", workingHour.settings.workHours)
        var workHr = workingHour.settings.workHours
        val calendar = Calendar.getInstance()
        val dayOfWeek = calendar[Calendar.DAY_OF_WEEK]
        val dt = Date()
        val dateFormat = SimpleDateFormat("kk")
        val format: String = dateFormat.format(dt)
        if (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ValueRange.of(9, 18).isValidIntValue(format.toLong()) &&
                        ValueRange.of(2, 6).isValidIntValue(dayOfWeek.toLong())
            } else {
                TODO("VERSION.SDK_INT < O")
            }
        ) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()

        } else {
            simpleMsg(this, getString(R.string.working_hour_finish))
        }
    }


}