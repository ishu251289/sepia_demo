package com.example.sepiapets.Views;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Toast;

import com.example.sepiapets.R;
import com.example.sepiapets.databinding.ActivityPetDetailsBinding;

public class PetDetailsActivity extends AppCompatActivity {
    ActivityPetDetailsBinding binding;
    String contentUrl = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this,R.layout.activity_pet_details);
        //setContentView(R.layout.activity_pet_details);
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            contentUrl = extras.getString("pet_details");
        }
        //Toast.makeText(this,"Ah gya ",Toast.LENGTH_SHORT).show();
        binding.contentUrl.setText(contentUrl);
        binding.contentUrl.setOnClickListener(v -> {
           Intent intent = new Intent(this, PetWebViewActivity.class);
           intent.putExtra("contentUrl", "" + contentUrl );
           startActivity(intent);

        });
    }
}