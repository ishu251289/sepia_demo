package com.example.sepiapets.Views;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.os.Bundle;

import com.example.sepiapets.Adapter.PetsAdapter;
import com.example.sepiapets.R;
import com.example.sepiapets.Utils.Utils;
import com.example.sepiapets.dataClass.Pet;
import com.example.sepiapets.dataClass.PetData;
import com.example.sepiapets.databinding.ActivityMainBinding;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding activityMainBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityMainBinding= DataBindingUtil.setContentView(this, R.layout.activity_main);
        getDataFromJson();
    }

    private void getDataFromJson() {
        String jsonFileString = Utils.getJsonFromAssets(getApplicationContext(), "pets_list.json");
        Gson gson = new Gson();
        Type listUserType = new TypeToken<PetData>() { }.getType();
        PetData users = gson.fromJson(jsonFileString, listUserType);
        ArrayList<Pet> petList = new ArrayList<>();
        petList.addAll(users.getPets());
        setAdapter(petList);
    }

    private void setAdapter(ArrayList<Pet> petList) {
        PetsAdapter adapter = new PetsAdapter(this,petList);
        activityMainBinding.petRecylerView.setHasFixedSize(true);
        activityMainBinding.petRecylerView.setLayoutManager(new LinearLayoutManager(this));
        activityMainBinding.petRecylerView.setAdapter(adapter);
    }
}