package com.example.sepiapets.Utils;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.text.TextUtils;
import android.util.Log;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.io.InputStream;

public class Utils {

    public static String getJsonFromAssets(Context context, String fileName) {
        String jsonString;
        try {
            InputStream is = context.getAssets().open(fileName);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            jsonString = new String(buffer, "UTF-8");
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        return jsonString;
    }
    public static void loadImage(String url, ImageView imageView, int placeHolder) {
        if (TextUtils.isEmpty(url))
            Picasso.get().load(placeHolder).placeholder(placeHolder).error(placeHolder).into(imageView);
        else
            Picasso.get().load(url).placeholder(placeHolder).error(placeHolder).into(imageView);
    }
    public static void simpleMsg(Activity activity, String msg) {
        try {
            if (TextUtils.isEmpty(msg))
                return;
            AlertDialog.Builder simplebuilder = new AlertDialog.Builder(activity);
            simplebuilder.setCancelable(false);
            simplebuilder.setTitle("Message");
            simplebuilder.setMessage(msg);
            simplebuilder.setPositiveButton("Ok", (dialog, which) -> {
                if (dialog != null) {
                    dialog.dismiss();
                    activity.finish();
                }

            });
            Dialog simpleDialog = simplebuilder.create();
            if (!activity.isFinishing() && !simpleDialog.isShowing()) {
                simpleDialog.show();
            } else {
                Log.e("TAG", "SIMPLE");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}

